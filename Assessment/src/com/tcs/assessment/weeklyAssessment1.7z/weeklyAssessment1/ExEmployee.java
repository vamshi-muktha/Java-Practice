package com.tcs.assessment.weeklyAssessment1;

public class ExEmployee {
	public static void main(String[] args) {
		Employee e1 = new Employee();
		Employee e2 = new Employee(11, "Rohit", 70000, "Permanent");
		Employee e3 = new Employee(12, "Dhoni", 40000, "Permanent");
		
		System.out.println("Object using default constructor----------------------------------------");
		System.out.println(e1.display());
		System.out.println("Objects using parameterized constructor---------------------------------");
		System.out.println(e2.display());
		System.out.println(e3.display());
		
	}
}
